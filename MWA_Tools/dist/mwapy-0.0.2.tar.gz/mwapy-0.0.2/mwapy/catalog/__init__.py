"""
This module supports cataloging from within CASA or in python <=2.7

Dependencies:
AIPY 1.0
pyephem 3.7.4.1
"""
from generic_catalog import *

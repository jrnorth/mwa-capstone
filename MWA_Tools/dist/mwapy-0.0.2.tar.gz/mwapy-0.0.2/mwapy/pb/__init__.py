"""
This module defines a python interface into a simple model of the primary beam.
"""
import measured_beamformer,mwapb


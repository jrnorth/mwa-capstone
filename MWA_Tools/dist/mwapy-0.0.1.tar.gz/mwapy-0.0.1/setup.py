import os
from glob import glob
from distutils.core import setup
from distutils.command.install import install as DistutilsInstall
from setuptools import find_packages,Extension
from subprocess import call
# Utility function to read the README file.
# Used for the long_description.  It's nice, because now 1) we have a top level
# README file and 2) it's easier to type in the README file than to put a raw
# string in below ...
def read(fname):
    return open(os.path.join(os.path.dirname(__file__), fname)).read()


setup(
    name = "mwapy",
    version = "0.0.1",
    author = "D. Jacobs",
    author_email = "daniel.c.jacobs@asu.edu",
    description = ("Set of tools for using and developing the MWA."),
    license = "BSD",
    keywords = "MWA radio",
    url = "http://mwa-lfd.haystack.mit.edu",
    py_modules = ['mwa_32T_pb','mwaconfig'],
    packages=find_packages(),
    package_dir={'mwapy':'mwapy','':'configs'},
    scripts=glob('scripts/*py')+['CONV2UVFITS/corr2uvfits'],
    ext_modules=[
#    Extension('SLALIB',
#    glob('mwapy/CONV2UVFITS/SLALIB_C/*.o')
#    ),
#    Extension('CONV2UVFITS',
#        ['mwapy/CONV2UVFITS/corr2uvfits.c',
#        'mwapy/CONV2UVFITS/uvfits.c'],
#        libraries=['cfitsio','sla','m'],
#        library_dirs = ['mwapy/CONV2UVFITS/SLALIB_C'],
#        include_dirs = ['mwapy/CONV2UVFITS/SLALIB_C'],
#        )
#        extra_compile_args=[' -O -Wall -D_FILE_OFFSET_BITS=64 -L. '])
    ],
    long_description=read('README'),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Topic :: Utilities",
        "License :: OSI Approved :: BSD License",
    ],
    data_files=['configs/mwa.conf'],
    package_data={'mwapy.pb':['*.txt','*.fits'],
    'mwapy.catalog':['*.vot']})

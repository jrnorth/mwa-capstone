"""Empty stub file that will import with no errors if the 
   PYTHON_PATH is set correctly.

   This file is imported by mwaconfig.py, so most MWA python code should
   import this. Use it to put global initialisation code in here, if any.
"""

pass


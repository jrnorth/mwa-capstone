#!/usr/bin/env python

"""
Computes a grid of positions centered around the (RA,Dec) of body at the time given by <time> (GPS seconds or UT)
Grid extends from <innerradius> to <outerradius>
Each position has a nominal size of <tilesize>
Optional arguments: [--minaltitude=<minaltitude>] [--azimuthfactor=<azimuthfactor>] [--radiusfactor=<radiusfactor>]
Will eliminate all positions with altitude<minaltitude> (default=5)
Spaces positions in radius from object by 2*<tilesize>*<radiusfactor> (default=0.7)
Spaces positions in angle around object by ~(2*<tilesize>*cos(90-radius)*<azimuthfactor>), but adjust so that requires integer positions (default=1.0)
All angles in degrees
Returns (RA,Dec) of grid centers


$Rev$:     Revision of last commit
$Author$:  Author of last commit
$Date$:    Date of last commit

"""

import getopt, logging, sys, os, glob, string, re, urllib, math
import numpy
import ephem

import mwaconfig

try:
    import ppgplot
    doplot=1
    from obssched.base import polar_plotting
except:
    doplot=0
    logging.error("Plotting unavailable...\n")
from mwapy import ephem_utils

__version__ = "$Rev$"

MovingBodies=['Ariel',
 'Callisto',
 'Deimos',
 'Dione',
 'Enceladus',
 'Europa',
 'Ganymede',
 'Hyperion',
 'Iapetus',
 'Io',
 'Jupiter',
 'Mars',
 'Mercury',
 'Mimas',
 'Miranda',
 'Moon',
 'Neptune',
 'Oberon',
 'Phobos',
 'Pluto',
 'Rhea',
 'Saturn',
 'Sun',
 'Tethys',
 'Titan',
 'Titania',
 'Umbriel',
 'Uranus',
 'Venus']

######################################################################

def main():

    try:
        opts, args = getopt.getopt(sys.argv[1:], 
                                   "hn:t:r:d:a:e:i:o:s:p:",
                                   ["help","name=","time=",
                                    "ra=",
                                    "dec=",
                                    "az=",
                                    "el="
                                    "inner=","outer=","size=","radiusfactor=","azimuthfactor=","minaltitude=","plot="
                                    ])
    except getopt.GetoptError:
        # print help information and exit:
        usage()
        sys.exit(2)

    
    GPSseconds=None
    bodyname=None
    rin=None
    rout=None
    tilesize=None
    minaltitude=5
    radiusfactor=0.7
    azimuthfactor=1.0
    plotfilename=None
    ra=None
    dec=None
    az=None
    el=None

    for opt,val in opts:
        if opt in ("-h","--help"):
            usage()
            sys.exit(1)
        elif opt in ("-n","--name"):
            bodyname=val
        elif opt in ("-t","--time"):
            try:
                GPSseconds=int(val)
            except ValueError:
                [date,time]=val.split(",")
                [yr,mn,dy]=date.split("-")
                MJD=ephem_utils.cal_mjd(int(yr),int(mn),int(dy))
                UT=ephem_utils.sexstring2dec(time)
                GPSseconds=ephem_utils.calcGPSseconds(MJD,UT)
        elif opt in ("-i","--inner"):
            rin=float(val)
        elif opt in ("-o","--outer"):
            rout=float(val)
        elif opt in ("-s","--size"):
            tilesize=float(val)
        elif opt in ("--azimuthfactor",):
            azimuthfactor=float(val)
        elif opt in ("--radiusfactor",):
            radiusfactor=float(val)
        elif opt in ("--minaltitude",):
            minaltitude=float(val)
        elif opt in ("-p", "--plot"):
            plotfilename=val
        elif opt.lower() in ('--ra', '-r'):
            try:
                if (val.count(':')>0):
                    ra=ephem_utils.sexstring2dec(val)*15
                else:
                    ra=float(val)
            except:
                logging.error('Unable to parse RA: %s' % val)
        elif opt.lower() in ('--dec', '-d'):
            try:
                if (val.count(':')>0):
                    dec=ephem_utils.sexstring2dec(val)
                else:
                    dec=float(val)
            except:
                logging.error('Unable to parse Dec: %s' % val)
        elif opt.lower() in ('--az', '-a'):
            try:
                if (val.count(':')>0):
                    az=ephem_utils.sexstring2dec(val)
                else:
                    az=float(val)
            except:
                logging.error('Unable to parse azimuth: %s' % val)
        elif opt.lower() in ('--el', '-e'):
            try:
                if (val.count(':')>0):
                    el=ephem_utils.sexstring2dec(val)
                else:
                    el=float(val)
            except:
                logging.error('Unable to parse elevation: %s' % val)

        else:
            logging.error("Unknown option: %s" % opt)
            usage()
            sys.exit(1)
    hasradec=False
    hasazel=False
    movingbody=False
    if (ra is not None and dec is not None):
        hasradec=True
    if (az is not None and el is not None):
        hasazel=True

    # only specifying by name
    if (not hasradec and not hasazel):
        if (bodyname):
            bodynameraw=bodyname
            bodyname=bodyname[0].upper() + bodyname[1:].lower()
        else:
            logging.error("Must specify a body")
            logging.error("Known bodies: %s" % (",".join(MovingBodies)))
            sys.exit(1)
        if (MovingBodies.count(bodyname)==0):
            logging.error("Unknown body specified: %s" % bodyname)
            logging.error("Known bodies: %s" % (",".join(MovingBodies)))
            sys.exit(1)
        else:
            movingbody=True

    if (GPSseconds is None):
        logging.warning("No time specified: defaulting to now")
        GPSseconds=ephem_utils.GPSseconds_now()

    if (tilesize is None or rin is None or rout is None):
        logging.error('Must specify inner radius, outer radius, and tile size')
        sys.exit(1)
    
    observer=ephem.Observer()
    mwa=ephem_utils.Obs[ephem_utils.obscode['MWA']]
    observer.long=mwa.long/ephem_utils.DEG_IN_RADIAN
    observer.lat=mwa.lat/ephem_utils.DEG_IN_RADIAN
    observer.elevation=mwa.elev
        
    [mjd,ut]=ephem_utils.calcUTGPSseconds(GPSseconds)
    mwa_time=ephem_utils.Time(mwa)
    mwa_time.init(mjd,ut,islt=0)
    [yr,mn,dy]=ephem_utils.mjd_cal(mjd)
    time=ephem_utils.dec2sexstring(ut)
    observer.date='%d/%d/%d %s' % (yr,mn,dy,time)
    if (movingbody):
        body=ephem.__dict__[bodyname]()
    else:
        body=ephem.FixedBody()
        if (hasradec):
            body._ra=ephem_utils.dec2sexstring(ra/15)
            body._dec=ephem_utils.dec2sexstring(dec)
        else:
            [ha,dec]=ephem_utils.horz2eq(az,el,mwa_time.lat)
            ra=observer.sidereal_time()*ephem_utils.DEG_IN_RADIAN-ha
            body._ra=ephem_utils.dec2sexstring(ra/15)
            body._dec=ephem_utils.dec2sexstring(dec)
        body._epoch=observer.date
        body.name=bodyname
    body.compute(observer)


    if (body.alt < 0):
        logging.error("%s is not above the horizon" % body.name)
        sys.exit(0)
        
    [RA,Dec]=tile_body(body.ra*180/math.pi, body.dec*180/math.pi, mwa_time.LST*15, mwa_time.lat, rin, rout, tilesize, radiusfactor=radiusfactor, azimuthfactor=azimuthfactor)

    [Az,Alt]=ephem_utils.eq2horz(mwa_time.LST*15-numpy.array(RA),numpy.array(Dec),mwa_time.lat)

    UTs=ephem_utils.dec2sexstring(ut,digits=0,roundseconds=1)
    print "# At GPStime=%d[s] %04d-%02d-%02d (MJD %d) %s UT" % (GPSseconds,yr,mn,dy,mjd,UTs)
    print "# Zenith is at (RA,Dec)=(%s,%s)" % (observer.sidereal_time(), observer.lat)
    print "# %s is at: (RA,Dec)=(%s,%s), (Az,Alt)=(%s,%s)" % (body.name, body.ra,body.dec,body.az,body.alt)
    print "# Grid extends from %.1f[deg] to %.1f[deg], size=%.1f[deg]" % (rin,rout,tilesize)
    print "#  \tAz[deg]\t\tAlt[deg]\tRA[hr]\t\tDec[deg]"
    for i in xrange(len(Az)):
        print "%d\t%s\t%s\t%s\t%s" % (i+1,ephem_utils.dec2sexstring(Az[i],digits=0,roundseconds=1),ephem_utils.dec2sexstring(Alt[i],digits=0,roundseconds=1),ephem_utils.dec2sexstring(RA[i]/15.0,digits=0,roundseconds=1),ephem_utils.dec2sexstring(Dec[i],digits=0,roundseconds=1))

    if (doplot and plotfilename):
        if (plotfilename == '/xwin'):
            filename='/xwin'
        else:
            filename=plotfilename + '/vcps'
        plot_tilepositions(body.name, body.az*ephem_utils.DEG_IN_RADIAN, body.alt*ephem_utils.DEG_IN_RADIAN, Az, Alt, tilesize,  mwa_time.lat, GPSseconds, observer.sidereal_time()*ephem_utils.DEG_IN_RADIAN, filename=filename, proj='sin', minaltitude=minaltitude) 

    sys.exit(0)

######################################################################
def tile_body(body_ra, body_dec, LST, lat, innerradius, outerradius, tilesize, radiusfactor=0.7, azimuthfactor=1):
    """
    [RA,Dec]=tile_body(body_ra, body_dec, LST, lat, innerradius, outerradius, tilesize, radiusfactor=0.7, azimuthfactor=1)
    generates a grid of positions centered around the altitude and azimuth of a body given by (body_ra, body_dec)
    grid extends from innerradius to outerradius.
    each position has a nominal size of tilesize
    spaces positions in radius from object by 2*tilesize*radiusfactor
    spaces positions in angle around object by ~(2*tilesize*cos(90-radius)*azimuthfactor), but adjust so that requires integer positions
    all angles in degrees, including LST
    """
        
    # first, figure out positions given body at origin
    bodydist=[]
    bodyaz=[]
    
    dradius=2*tilesize*radiusfactor
    nradii=int((outerradius-innerradius)/dradius)+1
    for j in xrange(nradii):
        radius=innerradius+dradius*j
        dtheta=2*tilesize/math.cos((90-radius)*math.pi/180)*azimuthfactor
        n=int(math.floor(360/dtheta)+1)
        dtheta=360.0/n

        if (j/2.0 != math.floor(j/2.0)):
            theta0=dtheta/2.0
        else:
            theta0=0
        for i in xrange(n):
            theta=theta0+dtheta*i
            bodydist.append(radius)
            bodyaz.append(theta)
    # now translate to position of Body
    bodydist=numpy.array(bodydist)
    bodyaz=numpy.array(bodyaz)

    x=bodydist*numpy.cos(bodyaz*math.pi/180)
    y=bodydist*numpy.sin(bodyaz*math.pi/180)

    [body_az, body_alt]=ephem_utils.eq2horz(LST-body_ra, body_dec, lat)
    xnew=x*math.pi/180+(math.pi/2-body_alt*math.pi/180)*math.cos(body_az*math.pi/180)
    ynew=y*math.pi/180+(math.pi/2-body_alt*math.pi/180)*math.sin(body_az*math.pi/180)
    alt=(math.pi/2-numpy.sqrt(xnew**2+ynew**2))*180/math.pi
    az=numpy.arctan2(ynew,xnew)*180/math.pi

    [HA,Dec]=ephem_utils.horz2eq(az,alt,lat)
    RA=LST-HA
   
    return [list(RA),list(Dec)]

######################################################################
def usage():

    (xdir,xname)=os.path.split(sys.argv[0])
    print "Usage:  %s [-h] -n <bodyname> [-r <RA> -d <Dec>] [-a <Azimuth> -e <Elevation>] [-t <time>] -i <innerradius> -o <outerradius> -s <tilesize> [-p <plotfilename>]" % xname
    print "\tComputes a grid of positions centered around the (Alt,Az) of body at the time given by <time> (GPS seconds or UT, as YYYY-MM-DD,HH:MM:SS, defaults to now)"
    print "\tCan specify a moving body (from list below) or position by RA/Dec, Az/El"
    print "\tGrid extends from <innerradius> to <outerradius>"
    print "\tEach position has a nominal size of <tilesize>"
    print "\tOptional arguments: [--minaltitude=<minaltitude>] [--azimuthfactor=<azimuthfactor>] [--radiusfactor=<radiusfactor>]"
    print "\tWill eliminate all positions with altitude<minaltitude> (default=5)"
    print "\tSpaces positions in radius from object by 2*<tilesize>*<radiusfactor> (default=0.7)"
    print "\tSpaces positions in angle around object by ~(2*<tilesize>*cos(90-radius)*<azimuthfactor>), but adjust so that requires integer positions (default=1.0)"
    print "\tAll angles in degrees"
    print "\tReturns (Alt,Az) of grid centers"
    print "\tIf plot file (postscript or \"/xwin\") is specified, will plot results"
    print "\tKnown bodies: %s" % (",".join(MovingBodies))


######################################################################
def plot_tilepositions(name, Az0, Alt0, Az, Alt, tilesize, lat, GPSseconds, LST, filename='/xwin', proj='sin', minaltitude=10): 
    """
    plot_tilepositions(name, Az0, Alt0, Az, Alt, tilesize, lat, GPSseconds, LST, filename='/xwin', proj='sin', minaltitude=10)
    """
    ppgplot.pgopen(filename)
    ppgplot.pgpap(0.0,1.0)    
    lwidth=2
    cheight=1.125
    lstyle=1
    fstyle=3
    ppgplot.pgslw(lwidth)
    ppgplot.pgsch(cheight)
    ppgplot.pgsls(lstyle)
    ppgplot.pgscf(fstyle)
    ypmin=0.15
    ypmax=0.85
    xpmin=0.15
    xpmax=0.85
    ppgplot.pgsvp(xpmin,xpmax,ypmin,ypmax)

    ppgplot.pgbbuf()
    ppgplot.pgsch(0.0)
    # create window which is [-90,90] in both axes
    # but with no box
    # this will serve as the polar axes
    ppgplot.pgenv(-90.0,90.0,-90.0,90.0,1,-2)

    polar_plotting.altazaxes(lat, proj)
    
    ppgplot.pgsls(1)
    ppgplot.pgsci(3)
    [r0,theta0,x,y]=polar_plotting.altaz_toplot(Az0,Alt0,proj=proj)
    ppgplot.pgpt(numpy.array([x]),numpy.array([y]),4)

    ppgplot.pgsci(2)
    ppgplot.pgsch(0.5)
    for i in xrange(len(Az)):
        [r0,theta0,x0,y0]=polar_plotting.altaz_toplot(Az[i],Alt[i],proj=None)
        if (r0<90-minaltitude):
            [r,theta]=polar_plotting.polar_circle(r0,Az[i],tilesize)
            [r,theta,x,y]=polar_plotting.altaz_toplot(theta,90-r,proj=proj)
            ppgplot.pgline(x,y)
            [r0,theta0,x0,y0]=polar_plotting.altaz_toplot(Az[i],Alt[i],proj=proj)
            ppgplot.pgptxt(x0,y0,0,0.5,'%d' % (i+1))
    [r,theta,x,y]=polar_plotting.altaz_toplot(Az,Alt,proj=proj)
    r0=90-Alt
    ppgplot.pgsci(5)
    ppgplot.pgline(x[numpy.where(r0<90)],y[numpy.where(r0<90)])
    
    ppgplot.pgsci(1)
    ppgplot.pgsch(0.75)
    [mjd,ut]=ephem_utils.calcUTGPSseconds(GPSseconds)
    [yr,mn,dy]=ephem_utils.mjd_cal(mjd)
    UTs=ephem_utils.dec2sexstring(ut,digits=0,roundseconds=1)

    [HA0,Dec0]=ephem_utils.horz2eq(Az0,Alt0,lat)
    RA0=LST-HA0
    ppgplot.pgtext(-90,-87,"At GPStime=%d[s] %04d-%02d-%02d (MJD %d) %s UT" % (GPSseconds,yr,mn,dy,mjd,UTs))
    ppgplot.pgtext(-90,-83.25,"Zenith is at (RA,Dec)=(%s,%s)" % (ephem_utils.dec2sexstring(LST/15.0,digits=0,roundseconds=1),ephem_utils.dec2sexstring(lat,digits=0,roundseconds=1,includesign=1)))
    ppgplot.pgtext(-90,-79.5,"Center is at: (RA,Dec)=(%s,%s), (Az,Alt)=(%s,%s)" % (ephem_utils.dec2sexstring(RA0/15.0,digits=0,roundseconds=1),ephem_utils.dec2sexstring(Dec0,digits=0,roundseconds=1,includesign=1),ephem_utils.dec2sexstring(Az0,digits=0,roundseconds=1),ephem_utils.dec2sexstring(Alt0,digits=0,roundseconds=1,includesign=1)))
    ppgplot.pgtext(-90,-75.75,"For \"%s\"" % name)


    ppgplot.pgclos()

######################################################################

if __name__=="__main__":
    main()


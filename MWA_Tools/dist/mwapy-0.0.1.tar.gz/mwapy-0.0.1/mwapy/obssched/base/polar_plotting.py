"""
python classes/routines to define basics of plotting in polar coords

-) Make sure hourangle definition is correct
   should be HA=LST-RA
   or RA=LST-HA


$Rev$:     Revision of last commit
$Author$:  Author of last commit
$Date$:    Date of last commit

"""

import copy, os, shutil, glob, sys, string, re, types, getopt, types, logging
import datetime,time
import numpy,pyfits
import math,operator
from mwapy import ephem_utils
try:
    import ppgplot
    doplot=1
except:
    doplot=0
    logging.error("Plotting unavailable...\n")

__version__ = "$Rev$"


######################################################################
def polar_circle(r0,theta0,size):
    """
    [r,theta]=polar_circle(r0,theta0,size)
    returns the [r,theta] coordinates to plot a circle in polar coords
    centered at [r0,theta0] and with radius=size
    """

    beta=numpy.arange(361)
    r=numpy.sqrt(size**2+r0**2-2*size*r0*numpy.cos(beta*math.pi/180))
    theta=(180.0/math.pi)*numpy.arcsin((size/r)*numpy.sin(beta*math.pi/180))
    if (size > r0):
        # it flips to the other side
        # need to be careful
        betalimit=(180/math.pi)*math.atan2(math.sqrt(size**2-r0**2),r0)
        i=numpy.where((beta <= betalimit)+(beta >= (360-betalimit)))[0]
        theta[i[::-1]]=theta[i]+180
    theta+=theta0

    return [r,theta]


######################################################################
def altaz_toplot(az,alt,proj='sin'):
    """
    [r,theta,x,y]=altaz_toplot(az,alt,proj='sin')
    returns the (r,theta) coords for polar plotting,
    along with (x,y) coords for cartesian plotting
    taken from the (az,alt) coordinates
    proj='sin' or None
    """
    r=90-alt
    if (proj=='sin'):
        r=90*numpy.cos((90-r)*math.pi/180)
    theta=az+90
    x=r*numpy.cos(theta*math.pi/180)
    y=r*numpy.sin(theta*math.pi/180)

    return [r,theta,x,y]

######################################################################
def altazaxes(lat, proj='sin', ZA=[30, 60], HA=range(-12,13), Dec=range(-75,60,15)):

    ls0=ppgplot.pgqls()
    # draw spokes
    r=numpy.arange(90)
    if (proj=='sin'):
        r=90*numpy.cos((90-r)*math.pi/180)
    for j in xrange(4):
        theta=(j/4.0)*2*math.pi*numpy.ones(r.shape)
        ppgplot.pgline(r*numpy.cos(theta),r*numpy.sin(theta))
    # draw circles
    ZA.append(90)
    theta=numpy.arange(361)
    for j in xrange(len(ZA)):
        za=ZA[j]*numpy.ones(theta.shape)
        [r,theta,x,y]=altaz_toplot(theta,90-za,proj=proj)
        ppgplot.pgline(x,y)
        ppgplot.pgptxt(0,r[0],0,0.5,"%d\uo" % ((j+1)*30))
        
    # lines of constant hourangle
    dec=numpy.arange(-90,90)
    ppgplot.pgsls(2)
    for ha in HA:
        [az,alt]=ephem_utils.eq2horz(ha*numpy.ones(dec.shape)*15,dec,lat)
        [r,theta,x,y]=altaz_toplot(az,alt,proj=proj)
        r0=90-alt        
        ppgplot.pgline(x[numpy.where(r0<90)],y[numpy.where(r0<90)])
        if (abs(ha)<=5):
            [az,alt]=ephem_utils.eq2horz(ha*15,lat,lat)
            [r,theta,x,y]=altaz_toplot(az,alt,proj=proj)
            r0=90-alt
            ppgplot.pgptxt(x,y,0,0.5,"%d\uh" % (ha))

    # lines of constant dec
    ha=numpy.arange(-12,12.25,.25)
    for dec in Dec:
        [az,alt]=ephem_utils.eq2horz(ha*15,dec*numpy.ones(ha.shape),lat)
        [r,theta,x,y]=altaz_toplot(az,alt,proj=proj)
        r0=90-alt        
        ppgplot.pgline(x[numpy.where(r0<90)],y[numpy.where(r0<90)])
        
        [az,alt]=ephem_utils.eq2horz(0,dec,lat)
        [r,theta,x,y]=altaz_toplot(az,alt,proj=proj)
        r0=90-alt        
        if (dec<0):
            s="%d\uo" % dec
        else:
            s="+%d\uo" % dec
        ppgplot.pgptxt(x,y,0,0.5,s)

    ppgplot.pgptxt(0,85,0,0.5,"North")
    ppgplot.pgptxt(-85,1,0,0.5,"East")
    ppgplot.pgsls(ls0)

